SELECT
    {{ dbt_utils.star(
        from = source('CUSTOMERS')
    ) }},
FROM
    {{ source('CUSTOMERS') }}
