{% snapshot DBT_SEED_PRODUCTS %}
    {% set db = generate_database_name('HIST_DB') %}
    {% set schema = generate_snapshot_schema_name('VIA_SEED') %}
    {{ config(
        target_schema = schema,
        target_database = db,
        unique_key = "PRODUCT_ID",
        strategy = 'check',
        check_cols = 'PRICE',
    ) }}

    SELECT
        *
    FROM
        {{ ref('PRODUCTS') }}
        --FROM SEED
{% endsnapshot %}
